# veriface
 This is a file written by Vue based on Baidu AI live detection to call mobile camera and access interface
